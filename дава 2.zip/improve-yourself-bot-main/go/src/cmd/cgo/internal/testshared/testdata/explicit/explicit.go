package explicit

import (
	"testshared/implicit"
)

func E() int {
	return implicit.I()
}
